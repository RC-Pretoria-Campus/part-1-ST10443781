﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Media;
using System.Threading;

namespace CyberChatbot
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Cybersecurity Awareness Bot";
            DisplayASCIIArt();
            PlayRecording();

            TypeEffect("Hello! I'm here to help you stay safe online.");

            Console.Write("\nWhat is your name? ");
            string userName = Console.ReadLine();
            TypeEffect($"\nNice to meet you, {userName}!");

            while (true)
            {
                DisplaySectionHeader("Ask a Cybersecurity Question");
                Console.Write("> ");
                string input = Console.ReadLine()?.Trim();

                if (string.IsNullOrEmpty(input))
                {
                    TypeEffect("\nPlease enter a valid question.");
                    continue;
                }

                RespondToUser(input);
            }
        }

        // Method to play the voice greeting
        static void PlayRecording()
        {

            SoundPlayer player = new SoundPlayer(@"greeting.wav");
            player.PlaySync();
        }

        // ASCII 
        static void DisplayASCIIArt()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(@"
  _________  ____   ___     _____                  
  |_     _| |   _| | 0 |   /     \         |\    /|
    |   |   |  |_  |   /  |       |        | \  / |
    |   |   |   _| |   \  |   O   |        |  \/  |
    |   |   |  |_  | 0 |  |       |        |      |
    |___|   |____| |__/    \_____/ ________|      |
    
       ");
            Console.ResetColor();
        }

        //  displaying section headers
        static void DisplaySectionHeader(string title)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\n-------------------------------------");
            Console.WriteLine($" {title} ");
            Console.WriteLine("-------------------------------------");
            Console.ResetColor();
        }

        // Typing effect for better UI experience
        static void TypeEffect(string message, int delay = 50)
        {
            foreach (char c in message)
            {
                Console.Write(c);
                Thread.Sleep(delay);
            }
            Console.WriteLine();
        }

        // Normalize input before comparison
        static string NormalizeInput(string input)
        {
            return input?.Trim().ToLowerInvariant();
        }

        // Response system for basic cybersecurity questions
        static void RespondToUser(string input)
        {
            var responses = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { "how are you?", "I'm just a bot, but I'm here to help!" },
            { "what’s your purpose?", "I help users stay safe online by providing cybersecurity tips." },
            { "what can i ask you about?", "You can ask me about password safety, phishing, and safe browsing." },
            { "tell me about password safety", "Use strong, unique passwords and enable multi-factor authentication." },
            { "what is phishing?", "Phishing is a scam where attackers trick you into giving away sensitive information." },
            { "how do i browse safely?", "Avoid clicking on suspicious links and use a secure browser." }
        };

            string normalizedInput = NormalizeInput(input);

            if (responses.ContainsKey(normalizedInput))
            {
                TypeEffect("\n" + responses[normalizedInput]);
            }
            else
            {
                TypeEffect("\nI didn’t quite understand that. Could you rephrase?");
            }
    }
}
    }
